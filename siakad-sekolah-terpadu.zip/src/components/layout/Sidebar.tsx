import React from 'react';
import {
  LayoutDashboard,
  UserCheck,
  Users,
  CalendarDays,
  FileEdit,
  BarChart3,
  GraduationCap,
  Briefcase,
  Building,
  BookOpen,
  RefreshCw,
  Settings,
  Calendar,
  Lock,
  ChevronRight,
  Sparkles,
  QrCode,
} from 'lucide-react';

export type NavTab =
  | 'dashboard'
  | 'scan-kiosk'
  | 'attendance-student'
  | 'attendance-teacher'
  | 'schedules'
  | 'corrections'
  | 'holidays'
  | 'reports'
  | 'teachers'
  | 'students'
  | 'classes'
  | 'subjects'
  | 'sync'
  | 'settings'
  // Planned modules
  | 'mod-kesiswaan'
  | 'mod-akademik'
  | 'mod-kepegawaian'
  | 'mod-keuangan'
  | 'mod-sarpras'
  | 'mod-perpustakaan'
  | 'mod-ppdb'
  | 'mod-surat'
  | 'mod-komunikasi';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isOpen,
  onClose,
}) => {
  const activeNavItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'scan-kiosk', label: 'Mesin Scan Absensi', icon: QrCode, badge: 'Otomatis' },
    { id: 'attendance-student', label: 'Absensi Siswa', icon: Users, badge: 'Inti' },
    { id: 'attendance-teacher', label: 'Absensi Guru', icon: UserCheck, badge: 'Inti' },
    { id: 'schedules', label: 'Jadwal & Piket', icon: CalendarDays },
    { id: 'corrections', label: 'Koreksi Absensi', icon: FileEdit },
    { id: 'holidays', label: 'Hari Libur', icon: Calendar },
    { id: 'reports', label: 'Laporan & Ekspor', icon: BarChart3 },
    { id: 'teachers', label: 'Data Guru', icon: Briefcase },
    { id: 'students', label: 'Data Siswa', icon: GraduationCap },
    { id: 'classes', label: 'Data Kelas', icon: Building },
    { id: 'subjects', label: 'Mata Pelajaran', icon: BookOpen },
    { id: 'sync', label: 'Sinkronisasi & Offline', icon: RefreshCw },
    { id: 'settings', label: 'Pengaturan & Audit', icon: Settings },
  ];

  const plannedModules = [
    { id: 'mod-kesiswaan', label: 'Kesiswaan (Mutasi/Prestasi)', code: 'KES' },
    { id: 'mod-akademik', label: 'Akademik (Nilai & Rapor)', code: 'AKD' },
    { id: 'mod-kepegawaian', label: 'Kepegawaian & Cuti', code: 'KPG' },
    { id: 'mod-keuangan', label: 'Keuangan & SPP', code: 'KEU' },
    { id: 'mod-sarpras', label: 'Sarana & Prasarana', code: 'SAR' },
    { id: 'mod-perpustakaan', label: 'Perpustakaan Digital', code: 'PER' },
    { id: 'mod-ppdb', label: 'PPDB Online', code: 'PDB' },
    { id: 'mod-surat', label: 'Surat & Disposisi', code: 'SRT' },
    { id: 'mod-komunikasi', label: 'Pengumuman / Komunikasi', code: 'KOM' },
  ];

  const handleItemClick = (tabId: string) => {
    onSelectTab(tabId as NavTab);
    onClose();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 flex w-72 flex-col border-r border-slate-200 bg-white transition-transform duration-200 ease-in-out dark:border-slate-800 dark:bg-slate-900 lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* App Title Header */}
        <div className="flex h-16 items-center gap-3 px-6 border-b border-slate-100 dark:border-slate-800">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 font-black text-white shadow-md shadow-blue-500/20">
            SK
          </div>
          <div>
            <h1 className="text-sm font-black tracking-tight text-slate-900 dark:text-white leading-none">
              SIAKAD TERPADU
            </h1>
            <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
              Modul Absensi & Core
            </span>
          </div>
        </div>

        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
          {/* Active Modules */}
          <div>
            <div className="px-3 pb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              Menu Utama & Absensi
            </div>
            <nav className="space-y-1">
              {activeNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleItemClick(item.id)}
                    className={`flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-xs font-semibold transition ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon
                        className={`w-4 h-4 ${
                          isActive ? 'text-white' : 'text-slate-400 dark:text-slate-500'
                        }`}
                      />
                      <span>{item.label}</span>
                    </div>
                    {item.badge && (
                      <span
                        className={`rounded-md px-1.5 py-0.5 text-[10px] font-bold ${
                          isActive
                            ? 'bg-blue-500 text-white'
                            : 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Planned Modular Monolith Registry */}
          <div>
            <div className="flex items-center justify-between px-3 pb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                Modul Terencana
              </span>
              <span className="flex items-center gap-1 rounded bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 text-[10px] font-semibold text-slate-500">
                <Sparkles className="w-2.5 h-2.5 text-amber-500" />
                V2
              </span>
            </div>
            <nav className="space-y-1">
              {plannedModules.map((item) => {
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleItemClick(item.id)}
                    className={`flex w-full items-center justify-between rounded-xl px-3 py-2 text-xs font-medium transition ${
                      isActive
                        ? 'bg-slate-200 text-slate-900 dark:bg-slate-800 dark:text-white'
                        : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </div>
                    <ChevronRight className="w-3 h-3 text-slate-400 shrink-0" />
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Footer info */}
        <div className="border-t border-slate-100 p-4 dark:border-slate-800">
          <div className="rounded-xl bg-slate-50 p-3 dark:bg-slate-800/50 text-[11px]">
            <div className="font-semibold text-slate-700 dark:text-slate-300">
              Offline-First Engine
            </div>
            <div className="text-slate-500 dark:text-slate-400 mt-0.5">
              Data tersimpan lokal & sinkron otomatis saat online.
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
